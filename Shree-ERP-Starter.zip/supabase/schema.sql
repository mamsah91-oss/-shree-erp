-- Shree ERP: initial schema for profiles and role-based access.
-- Run in Supabase SQL Editor before inviting users.
create extension if not exists pgcrypto;

create type public.app_role as enum ('admin', 'teacher');

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null default '',
  role public.app_role not null default 'teacher',
  institution_name text not null default 'Shree ERP Institution',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table public.profiles enable row level security;

-- Users can read their own profile. Admin management should be performed via
-- trusted server-side tooling/service role, never by exposing service keys in the browser.
create policy "Users can read own profile"
on public.profiles for select
to authenticated
using (auth.uid() = id);

create policy "Users can update own basic profile"
on public.profiles for update
to authenticated
using (auth.uid() = id)
with check (auth.uid() = id);

-- Create a profile automatically for newly created auth users.
-- Role defaults to teacher; promote the first administrator manually in SQL Editor.
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer set search_path = ''
as $$
begin
  insert into public.profiles (id, full_name, role, institution_name)
  values (
    new.id,
    coalesce(new.raw_user_meta_data ->> 'full_name', ''),
    'teacher'::public.app_role,
    coalesce(new.raw_user_meta_data ->> 'institution_name', 'Shree ERP Institution')
  )
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
after insert on auth.users
for each row execute procedure public.handle_new_user();

-- IMPORTANT: After creating your first account, run this query with that account's
-- email to promote it to admin. Do not allow users to self-select admin in sign-up.
-- update public.profiles
-- set role = 'admin'
-- where id = (select id from auth.users where email = 'YOUR_ADMIN_EMAIL');

-- Before production, add server-side admin-only policies for any future student,
-- attendance, fee, or teacher-management tables.
