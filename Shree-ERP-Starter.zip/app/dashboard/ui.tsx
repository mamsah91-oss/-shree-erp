"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase/client";
import {
  GraduationCap, LayoutDashboard, Users, BookOpen, CalendarDays, Wallet,
  Settings, Search, Bell, Menu, X, ChevronDown, LogOut, UserRound,
  ShieldCheck, ArrowUpRight, MoreHorizontal, CircleHelp, School
} from "lucide-react";

type UserInfo = { email: string; name: string; role: string; institution: string };
const nav = [
  { label: "Overview", icon: LayoutDashboard, active: true },
  { label: "Students", icon: Users, active: false },
  { label: "Teachers", icon: GraduationCap, active: false },
  { label: "Classes & Subjects", icon: BookOpen, active: false },
  { label: "Attendance", icon: CalendarDays, active: false },
  { label: "Fees & Payments", icon: Wallet, active: false },
];
const stats = [
  { label: "Total students", value: "—", note: "Connect student module", icon: Users, tone: "lavender" },
  { label: "Teaching staff", value: "—", note: "Connect staff module", icon: GraduationCap, tone: "mint" },
  { label: "Classes", value: "—", note: "Add academic classes", icon: BookOpen, tone: "peach" },
  { label: "Attendance today", value: "—", note: "Attendance not configured", icon: CalendarDays, tone: "blue" },
];

export default function Dashboard({ user }: { user: UserInfo }) {
  const router = useRouter();
  const [menuOpen, setMenuOpen] = useState(false);
  const [profileOpen, setProfileOpen] = useState(false);
  const [activeNav, setActiveNav] = useState("Overview");
  const [loggingOut, setLoggingOut] = useState(false);

  async function signOut() {
    setLoggingOut(true);
    const supabase = createClient();
    await supabase.auth.signOut();
    router.replace("/login");
    router.refresh();
  }

  const displayName = user.name || user.email.split("@")[0] || "Admin";
  const role = user.role.toLowerCase() === "admin" ? "Administrator" : "Teacher";

  return (
    <div className="app-shell">
      {menuOpen && <button className="mobile-scrim" aria-label="Close navigation" onClick={()=>setMenuOpen(false)}/>}
      <aside className={`sidebar ${menuOpen ? "sidebar-open" : ""}`}>
        <div className="sidebar-brand"><span className="brand-mark"><GraduationCap size={23}/></span><span>Shree <b>ERP</b><small>EDUCATION MANAGEMENT</small></span><button className="close-sidebar" onClick={()=>setMenuOpen(false)} aria-label="Close menu"><X size={19}/></button></div>
        <div className="institution-switch"><span className="institution-icon"><School size={19}/></span><span><b>{user.institution}</b><small>Academic workspace</small></span><ChevronDown size={15}/></div>
        <span className="nav-caption">WORKSPACE</span>
        <nav className="side-nav" aria-label="Main navigation">
          {nav.map(item => <button key={item.label} onClick={()=>{setActiveNav(item.label);setMenuOpen(false)}} className={`nav-item ${activeNav===item.label ? "selected" : ""}`}><item.icon size={18}/><span>{item.label}</span>{item.label!=="Overview" && <span className="coming-dot"/>}</button>)}
        </nav>
        <div className="sidebar-spacer"/>
        <div className="help-card"><div className="help-icon"><CircleHelp size={18}/></div><b>Need a hand?</b><p>Your ERP workspace is ready to configure.</p><button onClick={()=>setActiveNav("Help & support")}>View setup guide <ArrowUpRight size={14}/></button></div>
        <button className="nav-item settings-item" onClick={()=>setActiveNav("Settings")}><Settings size={18}/><span>Settings</span></button>
        <div className="sidebar-bottom"><span className="online-dot"/><span>Workspace is connected</span><span className="version">v0.1</span></div>
      </aside>

      <main className="main-area">
        <header className="topbar">
          <button className="mobile-menu" aria-label="Open menu" onClick={()=>setMenuOpen(true)}><Menu size={21}/></button>
          <div className="breadcrumb">Workspace <span>/</span> <b>{activeNav}</b></div>
          <div className="top-actions"><div className="search-box"><Search size={16}/><input aria-label="Search" placeholder="Search anything…"/><kbd>⌘ K</kbd></div><button className="icon-button notification" aria-label="Notifications"><Bell size={19}/><i/></button><div className="profile-wrap"><button className="profile-button" onClick={()=>setProfileOpen(v=>!v)}><span className="avatar">{displayName.slice(0,1).toUpperCase()}</span><span className="profile-copy"><b>{displayName}</b><small>{role}</small></span><ChevronDown size={15}/></button>{profileOpen && <div className="profile-menu"><div className="profile-menu-email">{user.email}</div><button onClick={signOut} disabled={loggingOut}><LogOut size={16}/>{loggingOut ? "Signing out…" : "Sign out"}</button></div>}</div></div>
        </header>

        <div className="page-content">
          {activeNav !== "Overview" && <div className="preview-banner"><span><ShieldCheck size={17}/></span><div><b>{activeNav}</b><p>This module is planned for the next development phase. Your sign-in and dashboard are connected.</p></div><button onClick={()=>setActiveNav("Overview")}>Back to overview</button></div>}
          <section className="welcome-row"><div><div className="eyebrow">SUNDAY, OCTOBER 25, 2026</div><h1>Good to see you, {displayName} <span className="wave">✦</span></h1><p className="muted">Here’s what’s happening with your institution today.</p></div><button className="date-button"><CalendarDays size={16}/> Academic overview <ChevronDown size={15}/></button></section>

          <section className="notice-strip"><div className="notice-symbol"><ShieldCheck size={19}/></div><div><b>Your workspace is ready for setup</b><p>Login is active. Add school details and connect your student and staff records to populate live statistics.</p></div><button onClick={()=>setActiveNav("Settings")}>Configure workspace <ArrowUpRight size={16}/></button></section>

          <section className="stats-grid" aria-label="Institution statistics">{stats.map(stat=><article className="stat-card" key={stat.label}><div className="stat-top"><span>{stat.label}</span><span className={`stat-icon ${stat.tone}`}><stat.icon size={18}/></span></div><div className="stat-value">{stat.value}</div><div className="stat-bottom"><span>{stat.note}</span></div></article>)}</section>

          <section className="content-grid">
            <article className="panel activity-panel"><div className="panel-heading"><div><h2>Getting started</h2><p>Set up your institution step by step</p></div><button className="more-button" aria-label="More options"><MoreHorizontal size={20}/></button></div>
              <div className="setup-list">
                <div className="setup-row"><span className="setup-number done">✓</span><div><b>Secure sign-in</b><p>Supabase authentication is configured in the app.</p></div><span className="status-pill complete">Ready</span></div>
                <div className="setup-row"><span className="setup-number">2</span><div><b>Set institution profile</b><p>Add your school name and academic year.</p></div><button className="small-action" onClick={()=>setActiveNav("Settings")}>Set up</button></div>
                <div className="setup-row"><span className="setup-number">3</span><div><b>Invite teachers</b><p>Create staff accounts and assign the teacher role.</p></div><button className="small-action" onClick={()=>setActiveNav("Teachers")}>Open</button></div>
                <div className="setup-row"><span className="setup-number">4</span><div><b>Add classes & students</b><p>Prepare records for your first academic session.</p></div><button className="small-action" onClick={()=>setActiveNav("Students")}>Open</button></div>
              </div>
            </article>
            <article className="panel quick-panel"><div className="panel-heading"><div><h2>Quick actions</h2><p>Common administration tasks</p></div></div><div className="quick-actions">
              <button onClick={()=>setActiveNav("Teachers")}><span className="quick-icon violet"><Users size={19}/></span><span><b>Manage teachers</b><small>Staff accounts & roles</small></span><ArrowUpRight size={16}/></button>
              <button onClick={()=>setActiveNav("Students")}><span className="quick-icon green"><GraduationCap size={19}/></span><span><b>Student records</b><small>Admissions & profiles</small></span><ArrowUpRight size={16}/></button>
              <button onClick={()=>setActiveNav("Attendance")}><span className="quick-icon orange"><CalendarDays size={19}/></span><span><b>Take attendance</b><small>Daily class attendance</small></span><ArrowUpRight size={16}/></button>
              <button onClick={()=>setActiveNav("Settings")}><span className="quick-icon blue"><Settings size={19}/></span><span><b>Workspace settings</b><small>School details & setup</small></span><ArrowUpRight size={16}/></button>
            </div></article>
          </section>
          <footer className="page-footer"><span>© 2026 Shree ERP</span><span><ShieldCheck size={14}/> Secure workspace <span className="footer-sep">·</span> Built for education</span></footer>
        </div>
      </main>
    </div>
  );
}
