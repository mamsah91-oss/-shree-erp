import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import Dashboard from "./ui";

export default async function DashboardPage() {
  const supabase = await createClient();
  const { data: { user }, error } = await supabase.auth.getUser();
  if (error || !user) redirect("/login");

  const { data: profile } = await supabase
    .from("profiles")
    .select("full_name, role, institution_name")
    .eq("id", user.id)
    .maybeSingle();

  return <Dashboard user={{ email: user.email ?? "", name: profile?.full_name ?? "", role: profile?.role ?? "teacher", institution: profile?.institution_name ?? "Shree ERP Institution" }} />;
}
