"use client";

import { useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { createClient } from "@/lib/supabase/client";
import { GraduationCap, Eye, EyeOff, ShieldCheck } from "lucide-react";

export default function LoginPage() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");

  async function handleSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setError("");
    setNotice("");
    setBusy(true);
    try {
      const supabase = createClient();
      const { error: signInError } = await supabase.auth.signInWithPassword({ email, password });
      if (signInError) throw signInError;
      router.replace(searchParams.get("next") || "/dashboard");
      router.refresh();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Login nahi ho paya. Details check karein.");
    } finally {
      setBusy(false);
    }
  }

  async function handleReset() {
    if (!email) { setError("Password reset ke liye pehle email enter karein."); return; }
    setError(""); setNotice(""); setBusy(true);
    try {
      const supabase = createClient();
      const { error: resetError } = await supabase.auth.resetPasswordForEmail(email, {
        redirectTo: `${window.location.origin}/login`,
      });
      if (resetError) throw resetError;
      setNotice("Agar is email par account hai, to password reset link bhej diya jayega.");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Reset link bhejne mein dikkat hui.");
    } finally { setBusy(false); }
  }

  return (
    <main className="login-shell">
      <section className="login-brand">
        <div className="brand-lockup"><span className="brand-mark"><GraduationCap size={25}/></span><span>Shree <b>ERP</b></span></div>
        <div className="brand-copy">
          <span className="eyebrow light">SCHOOL & COLLEGE MANAGEMENT</span>
          <h1>Education ko<br/><em>simple</em> banayein.</h1>
          <p>Ek jagah par school operations, staff access aur daily administration.</p>
        </div>
        <div className="brand-footer"><ShieldCheck size={16}/> Secure role-based access</div>
        <div className="brand-orb orb-one"/><div className="brand-orb orb-two"/>
      </section>
      <section className="login-panel">
        <div className="mobile-brand"><span className="brand-mark"><GraduationCap size={22}/></span> Shree <b>ERP</b></div>
        <div className="login-card">
          <span className="eyebrow">WELCOME BACK</span>
          <h2>Sign in to your account</h2>
          <p className="muted">Apna registered email aur password enter karein.</p>
          <form onSubmit={handleSubmit} className="login-form">
            <label htmlFor="email">Email address</label>
            <input id="email" type="email" autoComplete="username" placeholder="admin@school.edu" value={email} onChange={e=>setEmail(e.target.value)} required/>
            <div className="password-label"><label htmlFor="password">Password</label><button type="button" className="text-button" onClick={handleReset} disabled={busy}>Forgot password?</button></div>
            <div className="password-wrap"><input id="password" type={showPassword ? "text" : "password"} autoComplete="current-password" placeholder="Enter your password" value={password} onChange={e=>setPassword(e.target.value)} required minLength={6}/><button type="button" aria-label={showPassword ? "Hide password" : "Show password"} className="eye-button" onClick={()=>setShowPassword(v=>!v)}>{showPassword ? <EyeOff size={18}/> : <Eye size={18}/>}</button></div>
            {error && <div className="alert error" role="alert">{error}</div>}
            {notice && <div className="alert success" role="status">{notice}</div>}
            <button className="primary-button" type="submit" disabled={busy}>{busy ? "Please wait…" : "Sign in"} <span>→</span></button>
          </form>
          <div className="login-note"><ShieldCheck size={17}/><span>Access is limited to authorised administrators and teachers.</span></div>
        </div>
        <p className="copyright">© {new Date().getFullYear()} Shree ERP · School & College Management</p>
      </section>
    </main>
  );
}
