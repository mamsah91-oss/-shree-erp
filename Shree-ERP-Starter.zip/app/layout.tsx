import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Shree ERP | School & College Management",
  description: "A simple, secure school and college management dashboard.",
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body>{children}</body></html>;
}
