# Shree ERP — Initial Starter

A responsive School/College ERP starter built with Next.js App Router, Supabase Auth/Postgres, and ready for Vercel deployment.

## Included
- Responsive login screen with password visibility toggle and password-reset email
- Supabase email/password authentication
- Protected `/dashboard` route and session refresh middleware
- Admin dashboard UI, responsive sidebar, profile menu, and sign-out
- Profile schema with `admin` / `teacher` roles
- Starter setup checklist and placeholder ERP modules

## 1. Requirements
- Node.js 20.9+ recommended
- A Supabase account/project
- Optional Vercel account for hosting

## 2. Install and run
```bash
npm install
cp .env.example .env.local
```
Set `.env.local` values from **Supabase → Project Settings → API**:
- `NEXT_PUBLIC_SUPABASE_URL`
- `NEXT_PUBLIC_SUPABASE_ANON_KEY` (or the publishable key shown by your project)

Then run:
```bash
npm run dev
```
Open `http://localhost:3000`.

## 3. Configure Supabase
1. Open your project's SQL Editor.
2. Run the full contents of `supabase/schema.sql`.
3. In Supabase Authentication, create your first user (or enable sign-up only temporarily for setup).
4. In SQL Editor, promote that user to admin using the commented query at the bottom of `schema.sql`, replacing `YOUR_ADMIN_EMAIL`.
5. For a real school deployment, turn off public sign-ups and invite/create teacher accounts through a trusted admin-only server workflow. Do not let users choose their own role.

## 4. Security notes before production
- Never expose a Supabase `service_role` or secret key in `NEXT_PUBLIC_*` variables or browser code.
- The app uses Supabase Auth for identity and middleware for route protection. The SQL schema lets users read their own profile only; role-based server authorization for future data modules still needs to be implemented before enabling sensitive data.
- Do not store student, parent, health, fee, or other sensitive records until you add appropriate tables, row-level security policies, audit logging, backups, and access checks.
- Add rate limiting / abuse protection and configure Supabase Auth redirect URLs for your deployed domain.
- The current dashboard is a UI starter; statistic values are placeholders, not live student counts.
- Consider pinning package versions and running `npm audit` before production.

## 5. Deploy to Vercel
1. Push this folder to a private GitHub repository.
2. Import the repository in Vercel.
3. Add `NEXT_PUBLIC_SUPABASE_URL` and `NEXT_PUBLIC_SUPABASE_ANON_KEY` in Vercel project environment variables.
4. Deploy.
5. In Supabase Auth URL Configuration, add your Vercel URL to Site URL / Redirect URLs.

## Next milestones
1. School profile and academic year settings
2. Teacher management (admin-only)
3. Student admission records
4. Classes / subjects
5. Attendance
6. Fees and receipts
7. Reports and exports
